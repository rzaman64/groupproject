package com.example.groupproject;

public class SongModel {
    private String songName;
    private String artistName;
    private String songIcon;

    public String getSongName() {
        return songName;
    }

    public String getArtistName() {
        return artistName;
    }

    public String getSongIcon() {
        return songIcon;
    }
}
